<?php
header("content-type:json/application");
include("connect.php");
require 'mail/PHPMailer.php';
require("mail/SMTP.php");
require 'mail/Exception.php';
$data = json_decode(file_get_contents("php://input"), true);
$name=$data['name'];

 $mobile=$data['mobile'];
 $current_address=$data['current_address'];
 $permanent_address=$data['permanent_address'];
 $aadhar_no=$data['aadhar_no'];
 $email=$data['email'];

 $pass=$data['password'];
 $password=md5($pass);

 
$t = openssl_random_pseudo_bytes(20);

//Convert the binary data into hexadecimal representation.

$token = bin2hex($t);
 //echo $token;
        
                $query2="select * from user_register where email='$email'";
                $res2=mysqli_query($con,$query2);
                if($row2=mysqli_fetch_array($res2))
                {
                        $response=array('status'=>'404', 'message'=>'Email Already Registered?');
                        echo json_encode($response,true);
                        exit();
                }
                else
                {
                        $query="insert into user_register(name,mobile,current_address,permanent_address,aadhar_no,email,password,email_status,token,date) values('$name','$mobile','$current_address','$permanent_address','$aadhar_no','$email','$password',0,'$token',now())";
                        $res=mysqli_query($con,$query);
                        if($res==true)
                        {
                           
                     
                                //Importing the conn connection script 
                                // include("databaseconnect.php");
                            
                                $mail = new PHPMailer\PHPMailer\PHPMailer();
                                //getting username password and phone number 
                            
                                
                                   
                                    $to = $email;
                                    
                                    $subject ='Thank you for your registration! Your account has been created. To active your account click on the link below:';
                                   
                                    $message = urldecode("https://hinjilicutmunicipality.in/database/varify.php?email=$email&token=$token");
                            
                                     try {
                                    
                                        $mail ->IsSmtp();
                                        $mail ->SMTPDebug = 0;
                                        $mail ->SMTPAuth = true;
                                        $mail ->SMTPSecure = 'ssl';
                                        $mail ->Host = "smtp.gmail.com";
                                        $mail ->Port = 465;
                                        $mail ->IsHTML(true);
                                        $mail ->Username ="dilipkumargupta631@gmail.com";
                                        $mail ->Password ="Dilip631@";    
                                        $mail->setFrom("dilipkumargupta631@gmail.com", 'Admin');
                                        $mail->addAddress($to, 'User');
                                        $mail->addReplyTo('dilipkumargupta631@gmail.com', 'Admin');
                                        
                                        $mail->isHTML(true);
                                        $mail->Subject = $subject;
                            
                                        $mail->Body = $message;
                                        $mail->send();
                            
                                                // header("location:../Login&Register.php");
                                   
                                     $response=array('status'=>'200', 'message'=>'Authentication send on your Email, Please verify your Email !!');

                                     echo json_encode($response, true);
                                           
                                    } 
                            
                            
                                    catch (Exception $e)
                                     {
                                                
                                //  header("location:../Login&Register.php");    
                                        
                                    }
                          
                            
                         }
                        
                        else
                        {

                            $response=array('status'=>'404', 'message'=>'wrong');
                            echo json_encode($response,true);
                            exit();
                        }
                }        
       
 ?>