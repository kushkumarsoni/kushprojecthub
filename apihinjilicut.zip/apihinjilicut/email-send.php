<?php

include('connect.php');
$data = json_decode(file_get_contents("php://input"), true);
$email=$data['email'];

    
$t = openssl_random_pseudo_bytes(20);
$token = bin2hex($t);
 //echo $token;

    header("Content-Type: application/json; charset=UTF-8");
    //Importing the conn connection script 
    // include("databaseconnect.php");
    require 'mail/PHPMailer.php';
    require("mail/SMTP.php");
    require 'mail/Exception.php';
    $mail = new PHPMailer\PHPMailer\PHPMailer();
    //getting username password and phone number 

    $sql = "UPDATE  user_register SET token='$token' WHERE email = '$email'";
    //If the query executed on the conn successfully 

    if(mysqli_query($con,$sql))
    {
        
       
        $to = $email;
        
        $subject ='Thank you for your registration! Your account has been created. To active your account click on the link below:';
       
        $message = urldecode("https://hinjilicutmunicipality.in/database/varify.php?email=$email&token=$token");

         try {
        
            $mail ->IsSmtp();
            $mail ->SMTPDebug = 0;
            $mail ->SMTPAuth = true;
            $mail ->SMTPSecure = 'ssl';
            $mail ->Host = "smtp.gmail.com";
            $mail ->Port = 465;
            $mail ->IsHTML(true);
            $mail ->Username ="dilipkumargupta631@gmail.com";
            $mail ->Password ="Dilip631@";    
            $mail->setFrom("dilipkumargupta631@gmail.com", 'Admin');
            $mail->addAddress($to, 'User');
            $mail->addReplyTo('dilipkumargupta631@gmail.com', 'Admin');
            
            $mail->isHTML(true);
            $mail->Subject = $subject;

            $mail->Body = $message;
            $mail->send();

                    // header("location:../Login&Register.php");
       
        
               
        } 


        catch (Exception $e) {
                    
    //  header("location:../Login&Register.php");    
            
        }

    }

 
    	




?>