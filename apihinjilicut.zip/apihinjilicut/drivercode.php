<?php
include("connect.php");
$name=$_POST['name'];
if (empty($_POST['name']))
 {
	$response=array('status'=>'404', 'message'=>'Plz enter the name');
    	echo json_encode($response,true);
    	exit();
 }

 $mobile=$_POST['mobile'];
if (empty($_POST['mobile']))
 {
    $response=array('status'=>'404', 'message'=>'Plz enter the mobile');
        echo json_encode($response,true);
        exit();
 }
 $email=$_POST['email'];
if (empty($_POST['email']))
 {
	$response=array('status'=>'404', 'message'=>'Plz enter the Email');
    	echo json_encode($response,true);
    	exit();
 }
 $pass=$_POST['password'];
if (empty($_POST['password']))
 {
	$response=array('status'=>'404', 'message'=>'Plz enter the Password');
    	echo json_encode($response,true);
    	exit();
 }
  $password=md5($pass);
 $address=$_POST['address'];
if (empty($_POST['address']))
 {
    $response=array('status'=>'404', 'message'=>'Plz enter your Address');
        echo json_encode($response,true);
        exit();
 }
 $live_status=$_POST['live_status'];

$t = openssl_random_pseudo_bytes(20);

//Convert the binary data into hexadecimal representation.

$token = bin2hex($t);
 //echo $token;
 $lat=$_POST['lat'];

 $lang=$_POST['lang'];

 
$query="insert into driver(name,mobile,email,password,address,live_status,token,lat,lang,date) values('$name','$mobile','$email','$password','$address','$live_status','$token','$lat','$lang',now())";
$res=mysqli_query($con,$query);
if($res==true)
{
    $response=array('status'=>'200', 'message'=>'success');
    echo json_encode($response,true);
    exit();
}
else
{

    $response=array('status'=>'404', 'message'=>'wrong');
    echo json_encode($response,true);
    exit();
}

 ?>