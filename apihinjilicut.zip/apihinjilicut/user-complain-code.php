<?php

header("content-type:json/application");

include("connect.php");

$data = json_decode(file_get_contents("php://input"), true);



$user_id=$data['user_id'];



 $subject=$data['subject'];
if (empty($data['subject']))

 {

	$response=array('status'=>'404', 'message'=>'Plz enter the Subject');

    	echo json_encode($response,true);

    	exit();

 }



 

 $message=$data['message'];
if (empty($data['message']))

 {

	$response=array('status'=>'404', 'message'=>'Plz enter the message');

    	echo json_encode($response,true);

    	exit();

 }

 




 

$query="insert into tbl_user_complain(user_id,subject,message,date) values('$user_id','$subject','$message',now())";

$res=mysqli_query($con,$query);

if($res==true)

{

    $response=array('status'=>'200', 'message'=>'complain given successfully');

    echo json_encode($response,true);

    exit();

}

else

{



    $response=array('status'=>'404', 'message'=>'wrong');

    echo json_encode($response,true);

    exit();

}



 ?>