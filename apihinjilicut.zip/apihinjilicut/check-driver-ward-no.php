<?php
header("content-type:application/json");

include("connect.php");
$data = json_decode(file_get_contents("php://input"), true);

$ward_no=$data['ward_no'];

$query="select * from driver where zone like '%$ward_no%' and live_status=1 ";
$res=mysqli_query($con,$query);
$list=array();
while($row=mysqli_fetch_assoc($res))
{
	$list[]=$row;
}
if($list==true)
{
    $response=array('status'=>'200', 'message'=>$list);
    echo json_encode($response,JSON_PRETTY_PRINT);
    exit();
}
else
{

    $response=array('status'=>'404', 'message'=>'not available in this service area');
    echo json_encode($response,JSON_PRETTY_PRINT);
    exit();
}
?>
