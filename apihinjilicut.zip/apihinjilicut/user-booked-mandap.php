<?php
header("content-type:json/application");
include("connect.php");
$data = json_decode(file_get_contents("php://input"), true);

 $mandap_id=$data['mandap_id'];
 $mandap_type=$data['mandap_type'];
 $user_id=$data['user_id'];
 $booking_type=$data['booking_type'];
 
 $booked_date=$data['booked_date'];

 $booking_status=$data['booking_status'];


 
            $query="insert into tbl_booking(mandap_id,mandap_type,user_id,booking_type,booked_date,booking_status,date) values('$mandap_id','$mandap_type','$user_id','$booking_type','$booked_date','$booking_status',now())";
            $res=mysqli_query($con,$query);
            if($res==true)
            {
                $response=array('status'=>'200', 'message'=>'booking successfuly go to paytam');
                echo json_encode($response,true);
                exit();
            }
            else
            {
                $response=array('status'=>'404', 'message'=>'wrong');
                echo json_encode($response,true);
                exit();
            }

 ?>