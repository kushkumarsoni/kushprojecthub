<?php
header("content-type:json/application");
include("connect.php");
$data = json_decode(file_get_contents("php://input"), true);

 $mandap_id=$data['mandap_id'];
 $mandap_type=$data['mandap_type'];

 
 $check_date=$data['check_date'];

  $query="select * from tbl_booking where  mandap_id='$mandap_id' and mandap_type='$mandap_type' AND booked_date LIKE '$check_date%' ";
    $res=mysqli_query($con,$query);
            if($row=mysqli_fetch_array($res))
            {
          
         
              
                 $message=' Already booked, mandap not available in this date?';
                 $response=array('status'=>'400', 'message'=>$message);
                 echo json_encode($response,true);
               
            }
            else
            {
                $message=' Available Mandap';
                $response=array('status'=>'200', 'message'=>$message);
                echo json_encode($response,true);
            }
       
            
        
            
            
 ?>