<?php 
echo $name=$_REQUEST['name'];
unlink('gallery/'.$name);


?>