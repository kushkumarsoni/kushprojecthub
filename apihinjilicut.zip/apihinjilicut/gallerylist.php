<?php
include("connect.php");
$query="select * from tbl_gallery";
$res=mysqli_query($con,$query);



?>
<table border="1" align="center">
<tr>
<th>ID</th>
<th>NAME</th>
<th>FILE</th>
<th>DATE&TIME</th>
<th>Download</th>
<th>Delete</th>
</tr>
<?php
while($row=mysqli_fetch_array($res))
{
?>
<tr>
	<td><?php echo $row['img_id'];?></td>
	<td><?php echo $row['img_name'];?></td>
	<td><img src="gallery/<?php echo $row['img_name'];?>" height="200px" width="200px"/></td>
	<td><?php echo $row['date'];?></td>
	<td><a href="http://localhost/apihinjilicut/gallery/<?php echo $row['img_name']?>">download</a></td>
	
	<td><a href="delete-img-folder.php?name=<?php echo $row['img_name']?>">delete</a></td>
</tr>



<?php
}
?>
</table>