<?php
header("content-type:json/application");
$data = json_decode(file_get_contents("php://input"), true);
$driver_id=$data['driver_id'];

$live_status=$data['live_status'];

 $lat=$data['lat'];

 $lang=$data['lang'];

include("connect.php");
$query3="update driver set live_status='$live_status',lat='$lat',lang='$lang' where driver_id='$driver_id'";
	$res=mysqli_query($con,$query3);

if($res==true)
{
   $response=array('status'=>'200', 'message'=>'success');
   echo json_encode($response,true);
   exit();
}
else
{
   $response=array('status'=>'403', 'message'=>'Wrong !');
   echo json_encode($response,true);
   exit();
}
?>