<?php
header("content-type:json/application");
include("connect.php");
$data = json_decode(file_get_contents("php://input"), true);

$user_id=$data['user_id'];
$category=$data['category'];
 $address=$data['address'];

 $ward_no=$data['ward_no'];
 $message=$data['message'];
 
 $lat=$data['lat'];

 $lang=$data['lang'];

 
$query="insert into tbl_user_complain(user_id,category,address,ward_no,message,lat,lang,date) values('$user_id','$category','$address','$ward_no','$message','$lat','$lang',now())";
$res=mysqli_query($con,$query);
if($res==true)
{
    $response=array('status'=>'200', 'message'=>'complain given successfully');
    echo json_encode($response,true);
    exit();
}
else
{

    $response=array('status'=>'404', 'message'=>'wrong');
    echo json_encode($response,true);
    exit();
}

 ?>