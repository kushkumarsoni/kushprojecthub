-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 27, 2020 at 02:36 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hinjilicut`
--

-- --------------------------------------------------------

--
-- Table structure for table `driver`
--

CREATE TABLE `driver` (
  `driver_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `live_status` int(5) NOT NULL,
  `service_name` varchar(1000) NOT NULL,
  `zone` varchar(10000) NOT NULL,
  `token` varchar(1000) NOT NULL,
  `lat` varchar(1000) NOT NULL,
  `lang` varchar(100) NOT NULL,
  `date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `driver`
--

INSERT INTO `driver` (`driver_id`, `name`, `mobile`, `email`, `password`, `address`, `live_status`, `service_name`, `zone`, `token`, `lat`, `lang`, `date`) VALUES
(1, 'd', '2', 'admin@gmail.com', 'dddd', '140, Vikas Nagar Road, Sector 11, Vikas Nagar, Lucknow, Uttar Pradesh', 1, '	 fdghger', '1', 'a32425246357', '26.89564775145975', ' 80.96734162576881', '9/12/2020'),
(2, 'house', 'TREND VILLA', 'Maharastra', 'aaaa', '20 December 2019 to 21 December 2020', 1, '	 fdghger', '3', '5774b86c05ea94a9a5d51bf64c9ff0467bb14cf7', '11111111111111111', '2222222', '2020-12-09 12:10:07'),
(4, 'high problems', 'best', 'dilipkumargupta2546@gmail.com', '74b87337454200d4d33f80c4663dc5e5', 'Pipraich Railway Station Road, Pipraich, Uttar Pradesh', 1, 'safhai', '3', '4d5c3bdab44ea64df1ac9976c24ef3f81ea19907', '26.8270048', '83.5327653', '2020-12-09 13:51:29');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(11) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(70) NOT NULL,
  `date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `email`, `password`, `date`) VALUES
(1, 'admin@gmail.com', '74b87337454200d4d33f80c4663dc5e5', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_booking`
--

CREATE TABLE `tbl_booking` (
  `booking_id` int(11) NOT NULL,
  `mandap_id` longtext NOT NULL,
  `mandap_type` varchar(1000) NOT NULL,
  `user_id` longtext NOT NULL,
  `booking_type` varchar(10000) NOT NULL,
  `booked_date` varchar(200) NOT NULL,
  `booking_status` varchar(10) NOT NULL,
  `payment_status` varchar(10) NOT NULL,
  `date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_booking`
--

INSERT INTO `tbl_booking` (`booking_id`, `mandap_id`, `mandap_type`, `user_id`, `booking_type`, `booked_date`, `booking_status`, `payment_status`, `date`) VALUES
(1, '1', 'marraige', '12', 'sadi', '2020-12-07', '0', '0', '2020-12-18 17:39:03'),
(2, '2', 'engegment', '13', 'birthday', '2020-12-10', '1', '0', '2020-5-18 17:39:03'),
(3, '2', 'engegment', '19', 'engegment', '2020-12-30', '1', '0', '2020-12-10 17:39:03'),
(4, '4', 'marraige', '21', 'birthday', '2021-01-07', '1', '0', '2020-10-18 17:39:03'),
(5, '2', 'engegment', '28', 'engegment', '2020-10-07', '0', '0', '2020-11-18 17:39:03'),
(6, '', '', '21', '', '', '', '', '2020-12-26 17:07:02'),
(7, '21', '21', '21', '21', '21', '21', '', '2020-12-26 17:09:34');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gallery`
--

CREATE TABLE `tbl_gallery` (
  `img_id` int(11) NOT NULL,
  `img_name` mediumtext NOT NULL,
  `title` varchar(10000) NOT NULL,
  `date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_gallery`
--

INSERT INTO `tbl_gallery` (`img_id`, `img_name`, `title`, `date`) VALUES
(1, 'hinjilicut3.jpg', 'title1', '24/12/2020'),
(2, 'hinjicut1.jpg', 'title2', '25/12/2020'),
(3, 'hinjilicut2.jpg', 'title3', '26/12/2020');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_issues`
--

CREATE TABLE `tbl_issues` (
  `issue_id` int(11) NOT NULL,
  `driver_id` longtext NOT NULL,
  `type` varchar(30) NOT NULL,
  `address` varchar(200) NOT NULL,
  `house_no` varchar(100) NOT NULL,
  `message` mediumtext NOT NULL,
  `lat` varchar(200) NOT NULL,
  `lang` varchar(200) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_issues`
--

INSERT INTO `tbl_issues` (`issue_id`, `driver_id`, `type`, `address`, `house_no`, `message`, `lat`, `lang`, `date`) VALUES
(1, '', 'garvage\nPinterest\nBeautiful ho', '20 December 2019 to 21 December 2020', '23\nPinterest\nBeautiful houses - Sök på Google | Wallpaper house design, Simple house design, Beautif', '', 'mumba', 'best', '2020-12-09 14:21:03'),
(2, '', 'sadas', 'asffa', 'adsdsa', '', 'asda', 'asdad', '2020-12-09 18:15:11'),
(3, '', 'Garbag issue', 'gddhdhjs', '23', '', '37', '-95', '2020-12-10 10:31:49'),
(4, '', 'garbage', 'aaaa', '23', '', '37', '-95', '2020-12-10 11:21:24'),
(5, '', 'Garbage', 'Vikas Nagar', '23', '', '26.89421', '80.9640183', '2020-12-10 22:17:30'),
(6, '', 'Waiting Issue', 's nagar uttar ', '23', '', '26.89421', '80.9640183', '2020-12-10 22:28:55'),
(7, '', 'Garbage Issue', 'vkas nagar', '12', '', '80', '26', '2020-12-10 22:36:42'),
(8, '', 'Garbage Issue', 'lko', '23', '', '80', '26', '2020-12-10 22:38:00'),
(9, '', 'Garbage Issue', 'lko', '45', '', '26.89421', '80.9640183', '2020-12-10 22:38:52'),
(10, '', 'Waiting Issue', '', '34rgg', '', '26.89421', '80.9640183', '2020-12-11 10:43:57'),
(11, '', 'Waiting Issue', 'sgfdgdg', '23', '', '26.89421', '80.9640183', '2020-12-11 10:50:08'),
(31, '', '', '', '', '', '', '', '2020-12-24 15:57:35'),
(32, '', '', '', '', '', '', '', '2020-12-24 15:59:05'),
(33, '', 'a@gmail.com', '1234', 'sdfssdf', '', '1234', '1234', '2020-12-24 16:00:19'),
(34, '', 'a@gmail.com', '1234', '1234', 'sdfssdf', '1234', '1234', '2020-12-24 16:02:08'),
(35, '', '', '', '', '', '', '', '2020-12-24 16:03:27'),
(36, '', 'a@gmail.com', '1234', '1234', 'sdfssdf', '1234', '1234', '2020-12-24 16:04:15');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mandap`
--

CREATE TABLE `tbl_mandap` (
  `madnap_id` int(11) NOT NULL,
  `mandap_type` varchar(1000) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `area` mediumtext NOT NULL,
  `address` mediumtext NOT NULL,
  `images` varchar(10000) NOT NULL,
  `date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_mandap`
--

INSERT INTO `tbl_mandap` (`madnap_id`, `mandap_type`, `name`, `area`, `address`, `images`, `date`) VALUES
(1, 'marraige', 'kanyal mandap1', 'vikash nagar', 'lucknow', 'm1.jpg,m2.jpg', '26/12/2020'),
(2, 'engegment', 'kalyan madap2', 'flat 12', 'techpile technology vikash nagar', 'm3.jpg,m4.jpg', '26/12/2020'),
(3, 'engegment', 'kalyan mandap 3', ' middle', 'vikashnagar', 'm5.jpg,m6.jpg', '26/12/2020'),
(4, 'marraige', 'kalyan mandap 4', 'area 10', 'vikashnagar sector 8', 'm1.jpg,m5.jpg', '30/12/2020');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_service`
--

CREATE TABLE `tbl_service` (
  `service_id` int(11) NOT NULL,
  `service_name` varchar(1000) NOT NULL,
  `category` varchar(1000) NOT NULL,
  `zone` varchar(1000) NOT NULL,
  `assign_driver` varchar(1000) NOT NULL,
  `date` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_service`
--

INSERT INTO `tbl_service` (`service_id`, `service_name`, `category`, `zone`, `assign_driver`, `date`) VALUES
(1, 'fdghger', 'type', '1', 'ajay kumar', '25/12/2020'),
(2, 'dfglkjfgf', ' fgdfksf', '2', ' saytam yadav', ' 25/12/2020'),
(3, 'safhai', 'xyz', '3', 'aadarsh', '25/12/2020'),
(4, 'wwwww', 'type2', '4', 'vijay gupta', '15/12/2020');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_complain`
--

CREATE TABLE `tbl_user_complain` (
  `complain_id` int(11) NOT NULL,
  `user_id` longtext NOT NULL,
  `category` varchar(200) NOT NULL,
  `address` varchar(10000) NOT NULL,
  `ward_no` varchar(1000) NOT NULL,
  `lat` varchar(1000) NOT NULL,
  `lang` varchar(1000) NOT NULL,
  `message` mediumtext NOT NULL,
  `date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user_complain`
--

INSERT INTO `tbl_user_complain` (`complain_id`, `user_id`, `category`, `address`, `ward_no`, `lat`, `lang`, `message`, `date`) VALUES
(4, '5', 'saphai', 'gorakhpur', '1', '321248684743', '27633273373263', 'fsgdrhfgjhk tryu fegrthf fgrth', '2020-12-25 18:00:12'),
(5, '6', 'nali', 'lucknow', '6', '321248684743', '27633273373263', 'You can try this code. This is Simple PHP Image Deleting code from the server.', '2020-12-25 18:02:58');

-- --------------------------------------------------------

--
-- Table structure for table `user_register`
--

CREATE TABLE `user_register` (
  `user_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `current_address` varchar(10000) NOT NULL,
  `permanent_address` varchar(1000) NOT NULL,
  `aadhar_no` varchar(1000) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(1000) NOT NULL,
  `email_status` int(5) NOT NULL,
  `token` varchar(1000) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_register`
--

INSERT INTO `user_register` (`user_id`, `name`, `mobile`, `current_address`, `permanent_address`, `aadhar_no`, `email`, `password`, `email_status`, `token`, `date`) VALUES
(12, 'dilip', '444444444444', '', '', '', 'dilip.gupta@aaratechnologies.in', '8f60c8102d29fcd525162d02eed4566b', 1, 'd229b1beaa1888fdd5461843da1dfb53', '04/12/2020 12:44:10 am'),
(13, 'dilip singh', '444444444444', '', '', '', 'dilipkumargupta631@gmail.com', '74b87337454200d4d33f80c4663dc5e5', 0, 'a3ec2d686f8cb9be7972b6db6038081b', '09/12/2020 10:06:52 pm'),
(19, 'a@gmail.com', '1234', '1234', '1234', '1234', '123', '81dc9bdb52d04dc20036dbd8313ed055', 0, 'b922d8a33b71f7cc1bc0b35aa87373f089cec353', '2020-12-24 17:42:54'),
(21, 'gfuge', '1234', '1234', '1234', '1234', 'pankaj.alok99@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 0, '96dd01ca3c2add67d4f4b67c7a6791bb8a114293', '2020-12-24 18:52:09'),
(28, 'gfuge', '1234', '1234', '1234', '1234', 'dilipkumargupta2546@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 0, 'ae8d4c58171b4f89a5870f498d564fb7a0e229f8', '2020-12-24 19:39:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `driver`
--
ALTER TABLE `driver`
  ADD PRIMARY KEY (`driver_id`);

--
-- Indexes for table `tbl_booking`
--
ALTER TABLE `tbl_booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `tbl_gallery`
--
ALTER TABLE `tbl_gallery`
  ADD PRIMARY KEY (`img_id`);

--
-- Indexes for table `tbl_issues`
--
ALTER TABLE `tbl_issues`
  ADD PRIMARY KEY (`issue_id`);

--
-- Indexes for table `tbl_mandap`
--
ALTER TABLE `tbl_mandap`
  ADD PRIMARY KEY (`madnap_id`);

--
-- Indexes for table `tbl_service`
--
ALTER TABLE `tbl_service`
  ADD PRIMARY KEY (`service_id`);

--
-- Indexes for table `tbl_user_complain`
--
ALTER TABLE `tbl_user_complain`
  ADD PRIMARY KEY (`complain_id`);

--
-- Indexes for table `user_register`
--
ALTER TABLE `user_register`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `driver`
--
ALTER TABLE `driver`
  MODIFY `driver_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_booking`
--
ALTER TABLE `tbl_booking`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_gallery`
--
ALTER TABLE `tbl_gallery`
  MODIFY `img_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_issues`
--
ALTER TABLE `tbl_issues`
  MODIFY `issue_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `tbl_mandap`
--
ALTER TABLE `tbl_mandap`
  MODIFY `madnap_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_service`
--
ALTER TABLE `tbl_service`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_user_complain`
--
ALTER TABLE `tbl_user_complain`
  MODIFY `complain_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_register`
--
ALTER TABLE `user_register`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
