<?php
header("content-type:application/json");
$data = json_decode(file_get_contents("php://input"), true);
include("connect.php");
$user_id=$data['user_id'];

$query="select * from tbl_shop where user_id='$user_id' ";
$res=mysqli_query($con,$query);
$list=array();
while($row=mysqli_fetch_assoc($res))
{
	$list[]=$row;
}
if($list==true)
{
    $response=array('status'=>'200', 'message'=>$list);
    echo json_encode($response,JSON_PRETTY_PRINT);
    exit();
}
else
{

    $response=array('status'=>'404', 'message'=>'user_id not found');
    echo json_encode($response,JSON_PRETTY_PRINT);
    exit();
}
?>