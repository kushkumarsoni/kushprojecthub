<?php
header("content-type:application/json");

include("connect.php");
$data = json_decode(file_get_contents("php://input"), true);

$user_id=$data['user_id'];

$query="select * from tbl_user_complain where user_id='$user_id'order by complain_id desc ";
$res=mysqli_query($con,$query);
$list=array();
while($row=mysqli_fetch_assoc($res))
{
	$list[]=$row;
}
if($list==true)
{
    $response=array('status'=>'200', 'message'=>$list);
    echo json_encode($response,JSON_PRETTY_PRINT);
    exit();
}
else
{

    $response=array('status'=>'404', 'message'=>'user id not found');
    echo json_encode($response,JSON_PRETTY_PRINT);
    exit();
}
?>
