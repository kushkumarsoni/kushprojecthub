<?php
header("content-type:json/application");

$data = json_decode(file_get_contents("php://input"), true);

include("connect.php");

$name=$data['name'];
if (empty($data['name']))
 {
    $response=array('status'=>'404', 'message'=>'Plz enter the name');
        echo json_encode($response,true);
        exit();
 }


$email=$data['email'];
if (empty($data['email']))
 {
	$response=array('status'=>'404', 'message'=>'Plz enter the Email');
    	echo json_encode($response,true);
    	exit();
 }

 $token = openssl_random_pseudo_bytes(20);

//Convert the binary data into hexadecimal representation.

$token = bin2hex($token);
 //echo $token;


$query="select * from driver  where email='$email' and password='$password' ";
$res=mysqli_query($con,$query);

if($res==true)
{
                $list=array();
                while($row=mysqli_fetch_assoc($res))
                {
                    $list[]=$row;
                }
                if($list==true)
                {
                    $response=array('status'=>'200', 'message'=>$list);
                    echo json_encode($response,true);
                    exit();
                }
                else
                {
                    
                    $query2="select * from user_register  where email='$email' and password='$password' ";
                    $res2=mysqli_query($con,$query2);
                    if($res2==true)
                    {
                        $list=array();
                        while($row=mysqli_fetch_assoc($res2))
                        {
                            $list[]=$row;
                        }
                        if($list==true)
                        {
                            $response=array('status'=>'200', 'message'=>$list);
                            echo json_encode($response,true);
                            exit();
                        }
                        else
                         {
                            
                            $response=array('status'=>'404', 'message'=>'Invalid Email Or password');
                            echo json_encode($response,true);
                            exit();
                         } 
                    }

                    else
                    {
                       
                       $response=array('status'=>'404', 'message'=>'Invalid Email Or password');
                            echo json_encode($response,true);
                            exit();
                    } 
                }
                
}  
else
{

     $response=array('status'=>'404', 'message'=>'Invalid Email Or password');
                            echo json_encode($response,true);
                            exit();
    

}


?>