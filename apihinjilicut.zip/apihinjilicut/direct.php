<?php

$ho=$_SERVER['HTTP_HOST'];
$path='https://'.$ho.'/api/gallery';
echo $path;