<?php
header("content-type:application/json");

include("connect.php");

$query="select * from tbl_market";
$res=mysqli_query($con,$query);
$list=array();
while($row=mysqli_fetch_assoc($res))
{
	$list[]=$row;
}
if($list==true)
{
    $response=array('status'=>'200', 'message'=>$list);
    echo json_encode($response,JSON_PRETTY_PRINT);
    exit();
}
else
{

    $response=array('status'=>'404', 'message'=>'something went wrong');
    echo json_encode($response,JSON_PRETTY_PRINT);
    exit();
}
?>