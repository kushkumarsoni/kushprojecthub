<?php
header("content-type:json/application");
include("connect.php");
$data = json_decode(file_get_contents("php://input"), true);
$driver_id=$data['driver_id'];
$type=$data['type'];



 $address=$data['address'];

 $house_no=$data['house_no'];
 $message=$data['message'];
 
 $lat=$data['lat'];

 $lang=$data['lang'];

 
$query="insert into tbl_issues(driver_id,type,address,house_no,message,lat,lang,date) values('$driver_id','$type','$address','$house_no','$message','$lat','$lang',now())";
$res=mysqli_query($con,$query);
if($res==true)
{
    $response=array('status'=>'200', 'message'=>'success');
    echo json_encode($response,true);
    exit();
}
else
{

    $response=array('status'=>'404', 'message'=>'wrong');
    echo json_encode($response,true);
    exit();
}

 ?>