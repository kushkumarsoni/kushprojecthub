<?php
$con=mysqli_connect("localhost","root","","hinjilicut");
if($con==true)
{
	//echo "connection success";
}
else
{
	echo "Connection failed";
}

?>
