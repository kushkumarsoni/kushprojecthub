<?php
header("content-type:json/application");
include("connect.php");
$data = json_decode(file_get_contents("php://input"), true);

 $user_id=$data['user_id'];
 $market_id=$data['market_id'];
 $market_name=$data['market_name'];
 $market_area=$data['market_area'];
 
 $address=$data['address'];

 $lat=$data['lat'];
 $lang=$data['lang'];


            $query="insert into tbl_shop(user_id,market_id,market_name,market_area,address,lat,lang,varified_status,date) values('$user_id','$market_id','$market_name','$market_area','$address','$lat','$lang',0,now())";
            $res=mysqli_query($con,$query);
            if($res==true)
            {
                $response=array('status'=>'200', 'message'=>'shop applied successfully !');
                echo json_encode($response,true);
                exit();
            }
            else
            {
                $response=array('status'=>'404', 'message'=>'wrong');
                echo json_encode($response,true);
                exit();
            }

 ?>